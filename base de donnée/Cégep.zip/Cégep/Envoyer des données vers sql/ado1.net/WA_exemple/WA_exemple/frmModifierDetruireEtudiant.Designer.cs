﻿namespace WA_exemple
{
    partial class frmModifierDetruireEtudiant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpModifierDetruire = new System.Windows.Forms.GroupBox();
            this.txtCellulaire = new System.Windows.Forms.TextBox();
            this.lblCellulaire = new System.Windows.Forms.Label();
            this.NUDHumour = new System.Windows.Forms.NumericUpDown();
            this.lblDegreHumour = new System.Windows.Forms.Label();
            this.lblNom = new System.Windows.Forms.Label();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.lblPrenom = new System.Windows.Forms.Label();
            this.btnModification = new System.Windows.Forms.Button();
            this.btnDétruire = new System.Windows.Forms.Button();
            this.txtPrenom = new System.Windows.Forms.TextBox();
            this.grpRecherche = new System.Windows.Forms.GroupBox();
            this.cmbRecherche = new System.Windows.Forms.ComboBox();
            this.lblProvenance = new System.Windows.Forms.Label();
            this.cmbProvenance = new System.Windows.Forms.ComboBox();
            this.grpModifierDetruire.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NUDHumour)).BeginInit();
            this.grpRecherche.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpModifierDetruire
            // 
            this.grpModifierDetruire.Controls.Add(this.lblProvenance);
            this.grpModifierDetruire.Controls.Add(this.cmbProvenance);
            this.grpModifierDetruire.Controls.Add(this.txtCellulaire);
            this.grpModifierDetruire.Controls.Add(this.lblCellulaire);
            this.grpModifierDetruire.Controls.Add(this.NUDHumour);
            this.grpModifierDetruire.Controls.Add(this.lblDegreHumour);
            this.grpModifierDetruire.Controls.Add(this.lblNom);
            this.grpModifierDetruire.Controls.Add(this.txtNom);
            this.grpModifierDetruire.Controls.Add(this.lblPrenom);
            this.grpModifierDetruire.Controls.Add(this.btnModification);
            this.grpModifierDetruire.Controls.Add(this.btnDétruire);
            this.grpModifierDetruire.Controls.Add(this.txtPrenom);
            this.grpModifierDetruire.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpModifierDetruire.Location = new System.Drawing.Point(34, 159);
            this.grpModifierDetruire.Margin = new System.Windows.Forms.Padding(4);
            this.grpModifierDetruire.Name = "grpModifierDetruire";
            this.grpModifierDetruire.Padding = new System.Windows.Forms.Padding(4);
            this.grpModifierDetruire.Size = new System.Drawing.Size(451, 376);
            this.grpModifierDetruire.TabIndex = 24;
            this.grpModifierDetruire.TabStop = false;
            this.grpModifierDetruire.Text = "Modifier/détruire ";
            // 
            // txtCellulaire
            // 
            this.txtCellulaire.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCellulaire.Location = new System.Drawing.Point(159, 138);
            this.txtCellulaire.Margin = new System.Windows.Forms.Padding(4);
            this.txtCellulaire.Name = "txtCellulaire";
            this.txtCellulaire.Size = new System.Drawing.Size(240, 30);
            this.txtCellulaire.TabIndex = 28;
            // 
            // lblCellulaire
            // 
            this.lblCellulaire.AutoSize = true;
            this.lblCellulaire.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCellulaire.Location = new System.Drawing.Point(8, 138);
            this.lblCellulaire.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCellulaire.Name = "lblCellulaire";
            this.lblCellulaire.Size = new System.Drawing.Size(93, 25);
            this.lblCellulaire.TabIndex = 27;
            this.lblCellulaire.Text = "Cellulaire";
            // 
            // NUDHumour
            // 
            this.NUDHumour.Location = new System.Drawing.Point(161, 196);
            this.NUDHumour.Name = "NUDHumour";
            this.NUDHumour.Size = new System.Drawing.Size(238, 30);
            this.NUDHumour.TabIndex = 26;
            // 
            // lblDegreHumour
            // 
            this.lblDegreHumour.AutoSize = true;
            this.lblDegreHumour.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDegreHumour.Location = new System.Drawing.Point(8, 198);
            this.lblDegreHumour.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDegreHumour.Name = "lblDegreHumour";
            this.lblDegreHumour.Size = new System.Drawing.Size(151, 25);
            this.lblDegreHumour.TabIndex = 25;
            this.lblDegreHumour.Text = "Degré d\'humour";
            // 
            // lblNom
            // 
            this.lblNom.AutoSize = true;
            this.lblNom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNom.Location = new System.Drawing.Point(8, 91);
            this.lblNom.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNom.Name = "lblNom";
            this.lblNom.Size = new System.Drawing.Size(53, 25);
            this.lblNom.TabIndex = 19;
            this.lblNom.Text = "Nom";
            // 
            // txtNom
            // 
            this.txtNom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNom.Location = new System.Drawing.Point(159, 91);
            this.txtNom.Margin = new System.Windows.Forms.Padding(4);
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(240, 30);
            this.txtNom.TabIndex = 18;
            // 
            // lblPrenom
            // 
            this.lblPrenom.AutoSize = true;
            this.lblPrenom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrenom.Location = new System.Drawing.Point(8, 42);
            this.lblPrenom.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrenom.Name = "lblPrenom";
            this.lblPrenom.Size = new System.Drawing.Size(80, 25);
            this.lblPrenom.TabIndex = 15;
            this.lblPrenom.Text = "Prénom";
            // 
            // btnModification
            // 
            this.btnModification.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModification.Location = new System.Drawing.Point(39, 306);
            this.btnModification.Margin = new System.Windows.Forms.Padding(4);
            this.btnModification.Name = "btnModification";
            this.btnModification.Size = new System.Drawing.Size(117, 41);
            this.btnModification.TabIndex = 13;
            this.btnModification.Text = "Modifier";
            this.btnModification.UseVisualStyleBackColor = true;
            this.btnModification.Click += new System.EventHandler(this.btnModification_Click);
            // 
            // btnDétruire
            // 
            this.btnDétruire.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDétruire.Location = new System.Drawing.Point(284, 306);
            this.btnDétruire.Margin = new System.Windows.Forms.Padding(4);
            this.btnDétruire.Name = "btnDétruire";
            this.btnDétruire.Size = new System.Drawing.Size(115, 41);
            this.btnDétruire.TabIndex = 17;
            this.btnDétruire.Text = "Détruire";
            this.btnDétruire.UseVisualStyleBackColor = true;
            // 
            // txtPrenom
            // 
            this.txtPrenom.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrenom.Location = new System.Drawing.Point(159, 38);
            this.txtPrenom.Margin = new System.Windows.Forms.Padding(4);
            this.txtPrenom.Name = "txtPrenom";
            this.txtPrenom.Size = new System.Drawing.Size(240, 30);
            this.txtPrenom.TabIndex = 14;
            // 
            // grpRecherche
            // 
            this.grpRecherche.Controls.Add(this.cmbRecherche);
            this.grpRecherche.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpRecherche.Location = new System.Drawing.Point(34, 32);
            this.grpRecherche.Margin = new System.Windows.Forms.Padding(4);
            this.grpRecherche.Name = "grpRecherche";
            this.grpRecherche.Padding = new System.Windows.Forms.Padding(4);
            this.grpRecherche.Size = new System.Drawing.Size(451, 96);
            this.grpRecherche.TabIndex = 23;
            this.grpRecherche.TabStop = false;
            this.grpRecherche.Text = "Recherche d\'un étudiant";
            // 
            // cmbRecherche
            // 
            this.cmbRecherche.FormattingEnabled = true;
            this.cmbRecherche.Location = new System.Drawing.Point(8, 31);
            this.cmbRecherche.Margin = new System.Windows.Forms.Padding(4);
            this.cmbRecherche.Name = "cmbRecherche";
            this.cmbRecherche.Size = new System.Drawing.Size(391, 33);
            this.cmbRecherche.TabIndex = 1;
            // 
            // lblProvenance
            // 
            this.lblProvenance.AutoSize = true;
            this.lblProvenance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProvenance.Location = new System.Drawing.Point(7, 246);
            this.lblProvenance.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProvenance.Name = "lblProvenance";
            this.lblProvenance.Size = new System.Drawing.Size(117, 25);
            this.lblProvenance.TabIndex = 30;
            this.lblProvenance.Text = "Provenance";
            // 
            // cmbProvenance
            // 
            this.cmbProvenance.Font = new System.Drawing.Font("Corbel", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProvenance.FormattingEnabled = true;
            this.cmbProvenance.Location = new System.Drawing.Point(161, 244);
            this.cmbProvenance.Margin = new System.Windows.Forms.Padding(4);
            this.cmbProvenance.Name = "cmbProvenance";
            this.cmbProvenance.Size = new System.Drawing.Size(238, 32);
            this.cmbProvenance.TabIndex = 29;
            // 
            // frmModifierDetruireEtudiant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(530, 548);
            this.Controls.Add(this.grpModifierDetruire);
            this.Controls.Add(this.grpRecherche);
            this.Name = "frmModifierDetruireEtudiant";
            this.Text = "frmModifierDetruireEtudiant";
            this.Load += new System.EventHandler(this.frmModifierDetruireEtudiant_Load);
            this.grpModifierDetruire.ResumeLayout(false);
            this.grpModifierDetruire.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NUDHumour)).EndInit();
            this.grpRecherche.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.GroupBox grpModifierDetruire;
        internal System.Windows.Forms.Label lblNom;
        internal System.Windows.Forms.TextBox txtNom;
        internal System.Windows.Forms.Label lblPrenom;
        internal System.Windows.Forms.Button btnModification;
        internal System.Windows.Forms.Button btnDétruire;
        internal System.Windows.Forms.TextBox txtPrenom;
        internal System.Windows.Forms.GroupBox grpRecherche;
        internal System.Windows.Forms.ComboBox cmbRecherche;
        private System.Windows.Forms.NumericUpDown NUDHumour;
        private System.Windows.Forms.Label lblDegreHumour;
        private System.Windows.Forms.Label lblCellulaire;
        internal System.Windows.Forms.TextBox txtCellulaire;
        private System.Windows.Forms.Label lblProvenance;
        internal System.Windows.Forms.ComboBox cmbProvenance;
    }
}