﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace travail_pratique_2
{
    public partial class ModifierDetrureEntreprise : Form
    {
        public ModifierDetrureEntreprise()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_Modifier_Click(object sender, EventArgs e)
        {

        }

        private void btn_Detruire_Click(object sender, EventArgs e)
        {

        }

        private void btn_AjouterCategorie_Click(object sender, EventArgs e)
        {

        }
    }
}
